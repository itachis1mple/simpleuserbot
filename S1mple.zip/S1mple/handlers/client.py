# --------------------------------------------------- Client
from telethon import TelegramClient
api_id = 
api_hash = ""
client = TelegramClient('session', api_id, api_hash)
# -------------------------------------------------------
